var app = angular.module("auctionApp", []);

var API = "http://localhost:5000/api";

/* ===============================
   NOTIFICATION
   =============================== */

function showMessage(scope, title, text, type) {

    scope.message = {
        title: title,
        text: text,
        type: type
    };

    setTimeout(function() {
        scope.$apply(function() {
            scope.message = null;
        });
    }, 3500);
}

/* ===============================
   REGISTER
   =============================== */

app.controller("RegisterController",
function($scope, $http) {

    $scope.register = function() {

        $http.post(API + "/users/register", {
            name: $scope.name,
            email: $scope.email,
            password: $scope.password
        })

        .then(function(response) {

            showMessage(
                $scope,
                "Registration successful",
                "Your BIDNOVA account has been created.",
                "success"
            );

            setTimeout(function() {
                window.location.href = "login.html";
            }, 1800);
        })

        .catch(function(error) {

            showMessage(
                $scope,
                "Registration failed",
                error.data && error.data.message
                    ? error.data.message
                    : "Please try again.",
                "error"
            );
        });
    };
});

/* ===============================
   LOGIN
   =============================== */

app.controller("LoginController",
function($scope, $http) {

    $scope.login = function() {

        $http.post(API + "/users/login", {
            email: $scope.email,
            password: $scope.password
        })

        .then(function(response) {

            localStorage.setItem(
                "user",
                JSON.stringify(response.data.user)
            );

            showMessage(
                $scope,
                "Welcome back!",
                "Login successful. Opening auctions...",
                "success"
            );

            setTimeout(function() {
                window.location.href = "auctions.html";
            }, 1200);
        })

        .catch(function(error) {

            showMessage(
                $scope,
                "Login failed",
                error.data && error.data.message
                    ? error.data.message
                    : "Check your email and password.",
                "error"
            );
        });
    };
});

/* ===============================
   AUCTIONS
   =============================== */

app.controller("AuctionController",
function($scope, $http) {

    $scope.auctions = [];

    $http.get(API + "/auctions")

    .then(function(response) {
        $scope.auctions = response.data;
    })

    .catch(function(error) {

        console.log(error);

        showMessage(
            $scope,
            "Unable to load auctions",
            "Please make sure the backend is running.",
            "error"
        );
    });
});

/* ===============================
   LOGOUT
   =============================== */

app.controller("LogoutController",
function($scope) {

    $scope.logout = function() {

        localStorage.removeItem("user");

        window.location.href = "index.html";
    };
});

/* ===============================
   AUCTION DETAILS
   =============================== */

app.controller("AuctionDetailsController",
function($scope, $http) {

    var id = new URLSearchParams(
        window.location.search
    ).get("id");

    $scope.auction = null;

    $http.get(API + "/auctions/" + id)

    .then(function(response) {
        $scope.auction = response.data;
    })

    .catch(function() {

        showMessage(
            $scope,
            "Auction not found",
            "The selected auction could not be loaded.",
            "error"
        );
    });
});

/* ===============================
   ADMIN
   =============================== */

app.controller("AdminController",
function($scope, $http) {

    $scope.auctions = [];
    $scope.auction = {};

    function loadAuctions() {

        $http.get(API + "/auctions")

        .then(function(response) {
            $scope.auctions = response.data;
        });
    }

    loadAuctions();

    $scope.createAuction = function() {

        $http.post(
            API + "/auctions",
            $scope.auction
        )

        .then(function(response) {

            showMessage(
                $scope,
                "Auction created",
                "Your new auction is now available.",
                "success"
            );

            $scope.auction = {};

            loadAuctions();
        })

        .catch(function(error) {

            showMessage(
                $scope,
                "Could not create auction",
                error.data && error.data.message
                    ? error.data.message
                    : "Please try again.",
                "error"
            );
        });
    };

    $scope.closeAuction = function(id) {

        $http.put(
            API + "/auctions/" + id + "/close"
        )

        .then(function() {

            showMessage(
                $scope,
                "Auction closed",
                "The auction has been closed successfully.",
                "success"
            );

            loadAuctions();
        });
    };
});

/* ===============================
   BID
   =============================== */

app.controller("BidController",
function($scope, $http) {

    var id = new URLSearchParams(
        window.location.search
    ).get("id");

    $scope.auction = {};

    var savedUser =
        localStorage.getItem("user");

    if (!savedUser) {

        window.location.href =
            "login.html";

        return;
    }

    var user =
        JSON.parse(savedUser);

    $http.get(API + "/auctions/" + id)

    .then(function(response) {
        $scope.auction = response.data;
    })

    .catch(function() {

        showMessage(
            $scope,
            "Auction not found",
            "Unable to load this auction.",
            "error"
        );
    });

    $scope.placeBid = function() {

        if (!$scope.amount) {

            showMessage(
                $scope,
                "Enter a bid",
                "Please enter an amount before placing your bid.",
                "error"
            );

            return;
        }

        if (
            Number($scope.amount) <=
            Number($scope.auction.currentBid)
        ) {

            showMessage(
                $scope,
                "Bid not high enough",
                "Your bid must be higher than ₹"
                + $scope.auction.currentBid,
                "error"
            );

            return;
        }

        var data = {

            auctionId: id,

            userId: user.id,

            userName: user.name,

            amount: Number($scope.amount)
        };

        $http.post(
            API + "/bids",
            data
        )

        .then(function(response) {

            showMessage(
                $scope,
                "✓ Bid placed successfully",
                "Your bid of ₹"
                + $scope.amount
                + " has been submitted.",
                "success"
            );

            setTimeout(function() {

                window.location.href =
                    "auction.html?id=" + id;

            }, 1600);
        })

        .catch(function(error) {

            showMessage(
                $scope,
                "Bid could not be placed",
                error.data && error.data.message
                    ? error.data.message
                    : "Please try again.",
                "error"
            );
        });
    };
});

/* ===============================
   USER PROFILE
   =============================== */

app.controller("UserController",
function($scope) {

    $scope.user = JSON.parse(
        localStorage.getItem("user")
    );

    if (!$scope.user) {

        window.location.href =
            "login.html";

        return;
    }

    $scope.logout = function() {

        localStorage.removeItem("user");

        window.location.href =
            "index.html";
    };
});