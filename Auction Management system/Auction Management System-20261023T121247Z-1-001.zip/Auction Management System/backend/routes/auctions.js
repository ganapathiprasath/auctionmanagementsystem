const express = require("express");
const Auction = require("../models/Auction");

const router = express.Router();

// View all auctions
router.get("/", async (req, res) => {
    const auctions = await Auction.find();
    res.json(auctions);
});

// Create auction
router.post("/", async (req, res) => {
    try {
        const auction = new Auction({
            title: req.body.title,
            description: req.body.description,
            category: req.body.category,
            startingPrice: req.body.startingPrice,
            currentBid: req.body.startingPrice,
            endTime: req.body.endTime
        });

        await auction.save();

        res.json({
            message: "Auction created successfully",
            auction
        });

    } catch (error) {
        res.status(500).json({
            message: "Could not create auction"
        });
    }
});

// View one auction
router.get("/:id", async (req, res) => {
    const auction = await Auction.findById(req.params.id);

    if (!auction) {
        return res.status(404).json({
            message: "Auction not found"
        });
    }

    res.json(auction);
});

// Close auction
router.put("/:id/close", async (req, res) => {
    const auction = await Auction.findById(req.params.id);

    if (!auction) {
        return res.status(404).json({
            message: "Auction not found"
        });
    }

    auction.status = "Closed";
    await auction.save();

    res.json({
        message: "Auction closed",
        auction
    });
});

module.exports = router;