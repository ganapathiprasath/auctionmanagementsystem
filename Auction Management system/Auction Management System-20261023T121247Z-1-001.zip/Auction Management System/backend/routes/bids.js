const express = require("express");
const Bid = require("../models/Bid");
const Auction = require("../models/Auction");

const router = express.Router();

// Place a bid
router.post("/", async (req, res) => {
    try {
        const { auctionId, userId, userName, amount } = req.body;

        const auction = await Auction.findById(auctionId);

        if (!auction) {
            return res.status(404).json({
                message: "Auction not found"
            });
        }

        if (auction.status === "Closed") {
            return res.status(400).json({
                message: "Auction is closed"
            });
        }

        if (amount <= auction.currentBid) {
            return res.status(400).json({
                message: "Bid must be higher than current bid"
            });
        }

        const bid = new Bid({
            auctionId,
            userId,
            userName,
            amount
        });

        await bid.save();

        auction.currentBid = amount;
        auction.winner = userName;

        await auction.save();

        res.json({
            message: "Bid placed successfully",
            bid,
            currentBid: amount
        });

    } catch (error) {
        res.status(500).json({
            message: "Could not place bid"
        });
    }
});

// View bids for an auction
router.get("/:auctionId", async (req, res) => {
    const bids = await Bid.find({
        auctionId: req.params.auctionId
    }).sort({ amount: -1 });

    res.json(bids);
});

module.exports = router;