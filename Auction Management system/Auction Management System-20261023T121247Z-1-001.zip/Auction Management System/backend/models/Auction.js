const mongoose = require("mongoose");

const auctionSchema = new mongoose.Schema({
    title: String,
    description: String,
    category: String,
    startingPrice: Number,
    currentBid: Number,
    endTime: Date,
    status: {
        type: String,
        default: "Active"
    },
    winner: {
        type: String,
        default: ""
    }
});

module.exports = mongoose.model("Auction", auctionSchema);