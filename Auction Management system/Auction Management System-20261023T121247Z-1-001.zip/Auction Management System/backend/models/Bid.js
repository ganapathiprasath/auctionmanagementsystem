const mongoose = require("mongoose");

const bidSchema = new mongoose.Schema({
    auctionId: mongoose.Schema.Types.ObjectId,
    userId: mongoose.Schema.Types.ObjectId,
    userName: String,
    amount: Number,
    bidTime: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model("Bid", bidSchema);